#!/bin/sh

while
	read FILE
do
	echo -n $FILE " "
	expand $FILE | wc -c
done
